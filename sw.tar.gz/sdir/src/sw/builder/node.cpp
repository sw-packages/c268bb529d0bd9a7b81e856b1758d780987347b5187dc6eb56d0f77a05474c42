// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2017-2020 Egor Pugin

#include "node.h"

namespace sw
{

ICastable::~ICastable()
{
}

}
